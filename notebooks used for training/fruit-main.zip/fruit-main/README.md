# fruit

Project fruit is an example of object detection using pytorch.